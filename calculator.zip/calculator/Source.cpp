#include"Calculator.h"
int main()
{
	system("color 0c");
	Calculator obj;
	obj.Input();
	return 0;
}