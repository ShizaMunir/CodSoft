#pragma once
#include<iostream>
class Calculator
{
	double Num1;
	double Num2;
	double Result;
	char operation;

public:
	Calculator();
	void Input();
	void Division(double, double);
	void Multiplication(double, double);
	void Addition(double, double);
	void Subtraction(double, double);
	void display(char);
	~Calculator();
};

