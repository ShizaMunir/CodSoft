#include "Calculator.h"


Calculator::Calculator()
{
	Num1 = 0;
	Num2 = 0;
	Result = 0;
	operation = '\0';
}
void Calculator::Input()
{
	std::cout << "_____CALCULATOR________ \n";
	char check = '\0';
	while (1)
	{

		std::cout << "Enter first number : ";
		std::cin >> Num1;
		std::cout << "Enter Second number : ";
		std::cin >> Num2;
		std::cout << "Enter any one Operation |/,*,+,-| : ";
		std::cin >> operation;
		if (operation == '/')
		{
			Division(Num1, Num2);
		}
		if (operation == '*')
		{
			Multiplication(Num1, Num2);
		}
		if (operation == '+')
		{
			Addition(Num1, Num2);
		}
		if (operation == '-')
		{
			Subtraction(Num1, Num2);
		}
		std::cout << "\n\n|If you want to End press E.    |\n";
		std::cout << "|If you want to continue press C|\n ";
		std::cout << "Enter your choice :";
		std::cin >> check;
		if (check == 'E' || check == 'e')
		{
			std::cout << "\nTHANK YOOU\n";
			break;

		}
		if (check == 'C' || check == 'c' )
		{
			continue;
		}
	}


}
void Calculator::Division(double Num1, double Num2)
{
	if (Num2==0)
	{
		std::cout << "As Denminator is zero so answer will be undefined.\n";
		std::cout << "Re_Enter second number again : ";
		std::cin >> Num2;
		Result = Num1 / Num2;
	}
	else
	{
		Result = Num1 / Num2;
	}
	display('/');
}
void Calculator::Multiplication(double Num1, double Num2)
{
	Result = Num1 *Num2;
	display('*');
	
}
void Calculator::Addition(double Num1, double Num2)
{
	Result = Num1 + Num2;
	display('+');

}
void Calculator::Subtraction(double Num1, double Num2)
{
	Result = Num1 - Num2;
	display('-');
	
}
void Calculator::display(char operation)
{
	std::cout << Num1 << " "<<operation<<" " <<Num2<<" ="<<Result<<std::endl;
}

Calculator::~Calculator()
{
	if (operation!='\0')
	{
		operation == '\0';
	}
}
