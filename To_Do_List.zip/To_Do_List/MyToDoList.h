#pragma once
#include"ToDoList.h"


class MyToDoList :public ToDolist
{
public:
	 void display() ;
	 void AddTask();
	bool RemoveTask();
	void UpdateTask_Status( );
	void description();
};
void MyToDoList::description()
{
	cout << "\t\t\t\tTO_DO_LIST\n\n";
	cout << "________________________________________\n";
	cout << "|press 1: For Adding task INPUT.        |\n";
	cout << "|press 2: For mark task as COMPLETED.   |\n";
	cout << "|press 3: For VIEW tasks.               | \n";
	cout << "|press 4: For REMVOVE task              |  \n";
	cout << "|press 5: To EXIT.                      | \n";
	cout << "|_______________________________________|\n" << endl;
}
void MyToDoList::UpdateTask_Status()
{
	cout << "\t\t   ____________\n";
	cout << "\t\t  | MARK TASK  |\n";
	cout << "\t\t  |____________|\n";
	cout << "Enter task which you want to update :";

	string task;
	cin >> task;
	if (head==nullptr)
	{
		cout << "No task is Entered" << endl;
	}
	else
	{

		Node * pointer = head;
		while (1)
		{
			if (pointer->Task == task)//Delete from  head
			{
				pointer->Task_status = "Complete";
				break;
			}
			else
				pointer = pointer->next;

			if (pointer == nullptr)
			{
				cout << "Given task is not present" << endl;

			}
		}
	}	
}
bool MyToDoList::RemoveTask(  )
{
	cout << "\t\t   ____________\n";
	cout << "\t\t  | REMOVE TASK|\n";
	cout << "\t\t  |____________|\n";
	Node * pointer = head;
	int i = 1;
	while (1)
	{
		cout << i << " :" << pointer->Task << endl;
		i++;
		pointer = pointer->next;
		if (pointer==nullptr)
		{
			break;

		}
	}
	string temp;
	cout << "Enter Task which you want to remve from above list :  ";
	cin >> temp;
	
	if (head==nullptr)
	{
		cout << "No Task is added yet" << endl;
	}
	else if (head->next==nullptr )//single Node case
	{
		if (head->Task == temp)
		{
			delete head;
			head = nullptr;
			return true;
			
		}
		else
			return false;
	}
	
	else
	{
		Node * pointer = head;
		while (1)
		{
			 if (pointer->Task == temp)//Delete from  head
			{
				 Node *t = pointer;
				 head = head->next;
				delete t;
				t = nullptr;
				return true;
				break;
			}
			if (temp == pointer->next->Task)
			{
				break;
			}
			else
				pointer = pointer->next;

			if (pointer->next == nullptr)
			{
				return false;

			}
				
		}

		pointer->next = pointer->next->next;

	}
	
}
void MyToDoList::AddTask()
{
	cout << "\t\t   ____________\n";
	cout << "\t\t  | ADD TASK   |\n";
	cout << "\t\t  |____________|\n";
	string task;
	cout << "Enter Task : ";
	cin >> task;
	Node * newNode= new Node;
	newNode->Task = task;
	newNode->Task_status = "Incomplete";
	newNode->next = nullptr;
	if (head == nullptr)
	{
		head = newNode;
	}
	else 
	{
		Node * temp = head;
		while (1)
		{
			if (temp->next==nullptr)
			{
				temp->next = newNode;
				break;
			}
			temp = temp->next;
		}

	}	
}

void MyToDoList::display()
{
	if (head == nullptr)
		cout << "NO task is Entered " << endl;

	else
	{
		Node* temp = head;
		cout << "\t\t   ___________\n";
		cout << "\t\t  | VIEW TASKS|\n";
		cout << "\t\t  |___________|\n";
		int i = 1;
		while (1)
		{
			cout << "Task "<<i<<" : " << temp->Task << endl;
			cout<<"Status : " << temp->Task_status << endl;
			cout << endl;
			i++;
			temp = temp->next;
			if (temp == nullptr)
				break;
		}
		cout << endl;
	}
}