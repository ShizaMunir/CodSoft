#pragma once
#include<string>
#include<iostream>
using namespace std;
struct Node
{
	string Task;
	string Task_status;
	Node * next;
	
};

