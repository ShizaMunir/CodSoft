#include"MyToDoList.h"
int main()
{
	system("color 0c");
	obj.description();
	MyToDoList  obj;
	int choice;
	while (1)
	{
		
		cout << "\nEnter your choice :";
		cin >> choice;
		
		if (choice == 1)
		{
			
			obj.AddTask();
		}
		if (choice == 2)
		{
			obj.UpdateTask_Status();
		}
		if (choice == 3)
		{
			obj.display();
		}
		if (choice == 4)
		{
			
			obj.RemoveTask();
		}
		if (choice == 5)
		{
			cout << "Thank you!!!" << endl;
			break;
		}
	}
	return 0;
}