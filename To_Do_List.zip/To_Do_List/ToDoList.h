
#include"Node.h"

class ToDolist
{
protected:
	Node * head;
public:
	ToDolist();
	virtual void display() = 0;
	virtual void AddTask() = 0;
	virtual void UpdateTask_Status() = 0;
	virtual bool RemoveTask() = 0;
	virtual void description() = 0;

};
ToDolist::ToDolist()
{
	head = nullptr;
}